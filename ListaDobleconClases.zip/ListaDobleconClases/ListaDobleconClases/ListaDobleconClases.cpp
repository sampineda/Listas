#include "pch.h"
#include <iostream>
#include <string>

using namespace std;

class Alumno {
private: //atributos
	int cuenta;
	string nombre;
	string fecha;
	string telefono;
	//metodos: acciones que realice la clase 
public:
	Alumno(int, string, string, string); //constructor 
	/*void AgregarAlumno();
	void Actualizar();
	void Eliminar();
	void Listar();
	void Buscar();*/
};
//Inicializa constructor
Alumno::Alumno(int _cuenta, string _nombre, string _fecha, string _telefono) {
	cuenta = _cuenta;
	nombre = _nombre;
	fecha = _fecha;
	telefono = _telefono;
};

	int opcion = 0, cuen = 0;
	string nom, f_nac, num;

	Alumno alumno = Alumno(cuen, nom, f_nac, num);

struct  Nodo
{
	Alumno dato;
	Nodo *siguiente;
	Nodo *atras; 
} *primero, *ultimo, *nuevoptr, *ptr, *guardar; 

Nodo* nuevo(Alumno);

void AgregarAlumno(Nodo *);
void Actualizar();
void Eliminar();
void Listar();
void Buscar();


int main(){

	do
	{
		cout << "-------------Menu-------------\n";
		cout << "Seleccione una opcion: " << endl;
		cout << "1. Agregar alumno " << endl;
		cout << "2. Actualizar " << endl;
		cout << "3. Eliminar " << endl;
		cout << "4. Listar " << endl;
		cout << "5. Buscar " << endl;
		cout << "6. Salir " << endl;
		
	} while (opcion!=6);
	cout << "Opcion: ";
	cin >> opcion;

	switch (opcion)
	{
	case 1:
		cout << "Ingrese los datos que se le piden a continuacion: " << endl;
		cout << "Cuenta: ";
		cin >> cuen;
		cout << "Nombre: ";
		cin >> nom;
		cout << "Fecha de nacimiento: ";
		cin >> f_nac;
		cout << "Numero: ";
		cin >> num;

		nuevoptr = nuevo(alumno);
		AgregarAlumno(nuevoptr);

		cout << "\n";
		system("pause");
		break;
	case 2:
		cout << "\n";
		system("pause");
		break;
	case 3:
		cout << "\n";
		system("pause");
		break;
	case 4:
		Listar(primero);
		cout << "\n";
		system("pause");
		break;
	case 5:
		cout << "\n";
		system("pause");
		break;
	default:
		cout << "La opcion que ingreso es invalida. Por favor ingrese otra." << endl;
		break;
	}
};
Nodo *nuevo(Alumno al) { 
	ptr = new Nodo;
	ptr->dato = al;
	ptr->siguiente = NULL;
	return ptr;
}

void AgregarAlumno(Nodo *np) {
	if (primero == NULL) {
		primero = np;
		primero->siguiente = NULL;
		primero->atras = NULL;
		ultimo = primero;
	}
	else
	{
		ultimo->siguiente = np;
		np->siguiente = NULL;
		np->atras = ultimo;
		ultimo = np;
	}
}

void Listar(Nodo *np) {
	if (primero != NULL) {
		while (np != NULL)
		{
			cout << np->dato << "->";
			np = np->siguiente;
		}
	}
	else
	{
		cout << "La lista esta vacia." << endl;
	}
}

// Ejecutar programa: Ctrl + F5 o menú Depurar > Iniciar sin depurar
// Depurar programa: F5 o menú Depurar > Iniciar depuración

