#include "pch.h"
#include <iostream>
#include <conio.h>
#include<stdlib.h>
#include<stdio.h>
#include<time.h>

using namespace std;

struct Nodo
{
	int dato;
	Nodo *siguiente;
}*primero,*ultimo;


Nodo* nuevo = new Nodo();

void menu();
void InsertarNodo(Nodo *&, int);
void ImprimirLista(Nodo *);
void OrdenarLista(Nodo *);


void menu() {
	int r, num, i=0;
	do
	{
		cout << "----------------LISTAS----------------" << endl;
		cout << "1. Crear Lista" << endl;
		cout << "2. Imprimir lista" << endl;
		cout << "3. Ordenar Lista" << endl;
		cout << "4. Salir" << endl;
		cin >> r;

		switch (r)
		{
		case 1: 
			srand(time(NULL));
			num = (rand() % 20 + 1);
			InsertarNodo(nuevo, num);
			cout << "\n";
			system("pause");
			break;

		case 2:
			ImprimirLista(nuevo);
			cout << "\n";
			system("pause");
			break;

		case 3:
			break;

		default:
			break;
		}
		system("cls");
	} while (r != 4);

}

void InsertarNodo(Nodo *&nuevo, int n) {
	int cont=0;
	nuevo->dato = n;
	if (primero == NULL) {
		primero = nuevo;
		primero->siguiente = NULL;
		ultimo = nuevo;
	}
	else {
		ultimo->siguiente = nuevo;
		nuevo->siguiente = NULL;
		ultimo = nuevo;
		cont++;
	}
	if (cont <= 1) {
		cout << "Se ha ingresado " << cont + 1 << " numero a la lista." << endl;
	}
	else if (cont > 1) {

		cout << "Se han ingresado " << cont + 1 << " numeros a la lista." << endl;
	}
	
}

void ImprimirLista(Nodo *nuevo) {
	Nodo* actual = new Nodo();
	actual = nuevo;
	if (primero != NULL) {
		while (actual!=NULL)
		{
			cout << " " << actual->dato << endl;
			actual = actual->siguiente;
		}
	}
	else
	{
		cout << "La lista esta vacia.\n";
	}
}

int main()
{
	menu();
	return 0;
};



